import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const sampleData = [
  { name: "Jan", pedidos: 10 },
  { name: "Fev", pedidos: 25 },
  { name: "Mar", pedidos: 40 },
  { name: "Abr", pedidos: 30 },
];

export default function LandingPage() {
  return (
    <div className="relative min-h-screen text-white">
      <img
        src="/images/plandata-logo.png"
        alt="Fundo com logo PlanData BI"
        className="absolute inset-0 w-full h-full object-cover opacity-10 blur-md"
      />
      <div className="relative z-10 min-h-screen bg-gradient-to-b from-black/80 via-black/70 to-black/90 p-6">
        <div className="max-w-6xl mx-auto space-y-16">
          <header className="flex items-center justify-center pt-4">
            <img
              src="/images/plandata-logo.png"
              alt="Logo PlanData BI"
              className="w-14 h-14 mr-3 rounded-full border border-white shadow-md"
            />
            <h1 className="text-3xl font-bold tracking-wide">PlanData BI</h1>
          </header>
          <section className="text-center space-y-10 pt-10">
            <motion.h2
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-5xl md:text-6xl font-bold tracking-tight"
            >
              Domine sua produção com inteligência visual e gestão em tempo real
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto"
            >
              O PlanData BI é a plataforma inteligente que une planejamento estratégico, decisões assertivas e dados operacionais em tempo real.
            </motion.p>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
            >
              <Button className="text-lg px-8 py-4 rounded-2xl shadow-lg">
                Solicitar Demonstração Gratuita
              </Button>
            </motion.div>
          </section>
        </div>
      </div>
    </div>
  );
}
